'use strict';

/* Controllers */
var Controllers = angular.module('advdb.controllers', []);

Controllers.controller('loginCtrl', ['$scope','$http',function($scope,$http) {
	console.log('login ctrl');
}]);
